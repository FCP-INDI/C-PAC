Scripts that we run each time we process *new* data.  in other words, scripts in the QC folder generates things to *display* to the user, a set of figures per node or workflow.
