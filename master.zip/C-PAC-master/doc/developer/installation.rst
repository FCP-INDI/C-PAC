.. _installation:



***************
Installing CPAC
***************

.. _install_cpac:

Downloading the latest version of CPAC
======================================

This section describes how to download the latest developer version of CPAC
