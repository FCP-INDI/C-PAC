.. _testing:



************
Testing CPAC
************

.. _creating_tests:

Creating Tests
==============

This section describes how to create tests to verify the integrity of CPAC
