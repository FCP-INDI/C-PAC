Segmentation Workflow
=====================

.. automodule:: CPAC.seg_preproc
    :members:
