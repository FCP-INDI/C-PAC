Voxel Mirrored Homotopic Connectivity Analysis
==============================================

.. automodule:: CPAC.vmhc
    :members:
