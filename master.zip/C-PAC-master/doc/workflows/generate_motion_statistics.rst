Generate Motion and Power Statistics
====================================

.. automodule:: CPAC.generate_motion_statistics
    :members:
