Group Analysis
==============

.. automodule:: CPAC.group_analysis
    :members:
