Anatomical Preprocessing
========================

.. currentmodule:: anat_preproc
.. autofunction:: create_anat_preproc
