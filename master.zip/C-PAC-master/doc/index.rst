.. CPAC documentation master file, created by
   sphinx-quickstart on Fri Jun 22 13:46:06 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to CPAC's documentation!
================================

Contents:

.. toctree::
   :maxdepth: 2

   developer/index
   workflows/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

