cpac_install.sh Installation instructions:
1) Download the cpac_install_ubuntu.tar.gz file
2) tar xzf cpac_install_ubuntu.tar.gz
3) sudo ./cpac_install.sh
4) Open new terminal and launch "cpac_gui"

* NOTE: It is recommended to run on Ubuntu 12.04 LTS or newer. There may be issues with older versions. 
